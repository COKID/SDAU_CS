#include <stdio.h>

int main()
{
    int n;
    scanf("%d", &n);
    printf("%X", n);
    return 0;
}
