INSERT INTO bookstore.recommended (bookId) VALUES (1);
INSERT INTO bookstore.recommended (bookId) VALUES (5);
INSERT INTO bookstore.recommended (bookId) VALUES (7);