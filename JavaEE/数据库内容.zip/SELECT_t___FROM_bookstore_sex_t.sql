INSERT INTO bookstore.sex (sexType) VALUES ('男');
INSERT INTO bookstore.sex (sexType) VALUES ('女');
INSERT INTO bookstore.sex (sexType) VALUES ('未知');