INSERT INTO bookstore.type (typeName) VALUES ('文学');
INSERT INTO bookstore.type (typeName) VALUES ('历史');
INSERT INTO bookstore.type (typeName) VALUES ('天文');
INSERT INTO bookstore.type (typeName) VALUES ('地理');
INSERT INTO bookstore.type (typeName) VALUES ('其他');