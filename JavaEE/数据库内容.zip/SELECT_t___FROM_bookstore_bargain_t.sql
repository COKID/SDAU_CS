INSERT INTO bookstore.bargain (bookId, bookNewPrice) VALUES (1, 10);
INSERT INTO bookstore.bargain (bookId, bookNewPrice) VALUES (6, 12);
INSERT INTO bookstore.bargain (bookId, bookNewPrice) VALUES (5, 11);