package com.onlineBookStore.service;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.onlineBookStore.dao.UserinfoDAO;
import com.onlineBookStore.pojo.Bookinfo;
import com.onlineBookStore.pojo.Userinfo;
import com.onlineBookStore.util.HibernateSessionFactory;

public class UserinfoService {
	private UserinfoDAO userinfodao = new UserinfoDAO();

	public Userinfo login(String email, String password) {
		Userinfo u = null;
		List<Userinfo> users = null;

		users = userinfodao.findByProperty("email", email);
		if (users.size() > 0) {
			u = users.get(0);
			if (u.getPassword().equals(password)) {
				return u;
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public Userinfo addUser(Userinfo userinfo) {
		Session session = HibernateSessionFactory.getSession();
		Transaction ts = null;
		try {
			ts = session.beginTransaction();
			userinfodao.save(userinfo);
			ts.commit();
			return userinfo;
		} catch (Exception ex) {
			System.out.println(ex);
			ts.rollback();
			return null;
		} finally {
			session.close();
		}
	}

	public Userinfo modifyUser(Userinfo user, Userinfo userinfo) {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction ts = null;
		try {
			ts = session.beginTransaction();
			Userinfo u = userinfodao.findById(user.getId());

			u.setEmail(userinfo.getEmail());
			u.setPassword(userinfo.getPassword());

			userinfodao.attachDirty(u);
			ts.commit();
			return u;
		} catch (Exception ex) {
			System.out.println(ex);
			ts.rollback();
			return null;
		} finally {
			session.close();
		}

	}

	public Boolean deleteUser(int userid) {
		Session session = HibernateSessionFactory.getSessionFactory()
				.openSession();
		Transaction ts = null;
		try {
			ts = session.beginTransaction();
			Userinfo u = userinfodao.findById(userid);
			userinfodao.delete(u);
			return true;
		} catch (Exception ex) {
			System.out.println(ex);
			ts.rollback();
			return false;
		} finally {
			session.close();
		}

	}

	public Integer getUserSize() {
		List<Userinfo> userinfos = null;
		if (userinfodao.findAll().size() > 0) {
			userinfos = userinfodao.findAll();
		}
		return userinfos.size();
	}

	public Userinfo getUserById(int userid) {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSessionFactory()
				.openSession();
		Transaction ts = null;
		try {
			ts = session.beginTransaction();
			Userinfo u = userinfodao.findById(userid);
			return u;
		} catch (Exception ex) {
			System.out.println(ex);
			ts.rollback();
			return null;
		} finally {
			session.close();
		}

	}

	public Boolean modifyUserByAdmin(Userinfo userinfo) {
		// TODO Auto-generated method stub
		// System.out.println(userinfo.getPower());
		Session session = HibernateSessionFactory.getSession();
		Transaction ts = null;
		try {
			ts = session.beginTransaction();

			userinfodao.merge(userinfo);
			ts.commit();
			return true;
		} catch (Exception ex) {
			System.out.println(ex);
			ts.rollback();
			return false;
		} finally {
			session.close();
		}

		// return false;
	}
}
