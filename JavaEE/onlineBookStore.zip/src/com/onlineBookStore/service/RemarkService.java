package com.onlineBookStore.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.onlineBookStore.dao.RemarkDAO;
import com.onlineBookStore.pojo.Remark;
import com.onlineBookStore.util.HibernateSessionFactory;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.util.CycleDetectionStrategy;

public class RemarkService {
	private int rowCount;
	private RemarkDAO rd = new RemarkDAO();
	private List<Remark> remarks;

	@SuppressWarnings("unchecked")
	public List<?> list(int pageNo, int pageSize, String hql) {
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		List<Object> objects;
		Query query = session.createQuery(hql);
		query.setFirstResult(pageSize * (pageNo - 1));
		query.setMaxResults(pageSize);
		objects = query.list();
		tx.commit();
		return objects;
	}

	public String getAllCount(int pageNo, int pageSize, String hql) {
		//System.out.println(pageNo);
		@SuppressWarnings("unchecked")
		List<Remark> list = (List<Remark>) list(pageNo, pageSize, hql);
		List<Object> remarks=new ArrayList<Object>();
		for(Remark u:list){
			@SuppressWarnings("rawtypes")
			HashMap<String, Comparable> h=new HashMap<String, Comparable>();
			h.put("id", u.getId());
			h.put("bookName", u.getBookinfo().getBookName());
			h.put("userName", u.getUserinfo().getEmail());
			h.put("remark", u.getRemark());
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
			 
			String str=sdf.format(u.getDate());  
			h.put("date",str);
			remarks.add(h);
			
		}
		JSONArray json = JSONArray.fromObject(remarks);
		//System.out.println(json.toString());
		return json.toString();

	}

	@SuppressWarnings("unchecked")
	public int count(String hql) {
		Session session = HibernateSessionFactory.getSessionFactory()
				.openSession();
		Transaction tx = session.beginTransaction();

		Object query = session.createQuery(hql).uniqueResult();
		tx.commit();
		// session.close();

		session.close();
		return (int) (long) query;
	}

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

}
