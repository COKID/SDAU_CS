package com.onlineBookStore.service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.onlineBookStore.dao.BookinfoDAO;
import com.onlineBookStore.pojo.Bookinfo;
import com.onlineBookStore.pojo.Userinfo;
import com.onlineBookStore.util.HibernateSessionFactory;

public class BookinfoService {
	static final String novel = "小说";
	static final String art = "文艺";
	static final String youth = "青春";
	static final String motivational = "励志";
	static final String tale = "童话";
	static final String life = "生活";
	static final String science = "社科";
	static final String management = "经管";
	static final String technology = "科技";
	static final String education = "教育";

	private BookinfoDAO bfd = new BookinfoDAO();

	public List<Bookinfo> getLastBook() {
		List<Bookinfo> bookinfos = null;
		if (bfd.findAll().size() > 0) {
			bookinfos = bfd.findAll();
		}
		return bookinfos;

	}

	public Integer getBookSize() {
		List<Bookinfo> bookinfos = null;
		if (bfd.findAll().size() > 0) {
			bookinfos = bfd.findAll();
		}
		return bookinfos.size();
	}

	public Bookinfo getBookById(int bookid) {
		// TODO Auto-generated method stub
		Bookinfo bookinfo = null;
		bookinfo = bfd.findById(bookid);
		if (bookinfo != null) {
			return bookinfo;
		}
		return null;

	}

	public boolean addBookinfo(Bookinfo bookinfo) {
		// String
		Date date = new Date();//
		Timestamp timeStamp = new Timestamp(date.getTime());//
		bookinfo.setDate(timeStamp);//
		bookinfo.setIsbn(BookinfoService.getPswd());

		Session session = HibernateSessionFactory.getSession();
		Transaction ts = null;
		try {
			ts = session.beginTransaction();
			bfd.save(bookinfo);
			ts.commit();
			return true;
		} catch (Exception ex) {
			ts.rollback();
			System.out.println(ex);
			return false;
		} finally {
			session.close();
		}
	}

	public boolean deleteBook(int bookid) {
		Session session = HibernateSessionFactory.getSessionFactory()
				.openSession();
		Transaction ts = null;
		try {
			ts = session.beginTransaction();
			Bookinfo b = bfd.findById(bookid);
			bfd.delete(b);
			return true;
		} catch (Exception ex) {
			System.out.println(ex);
			ts.rollback();
			return false;
		} finally {
			session.close();
		}

	}

	public static String getPswd() {
		StringBuffer buf = new StringBuffer(
				"a,b,c,d,e,f,g,h,i,g,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z");
		buf.append(",A,B,C,D,E,F,G,H,I,G,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z");
		buf.append(",1,2,3,4,5,6,7,8,9,0");
		String[] arr = buf.toString().split(",");
		StringBuffer b = new StringBuffer();
		java.util.Random r;
		int k;
		for (int i = 0; i < 16; i++) {
			r = new java.util.Random();
			k = r.nextInt();
			b.append(String.valueOf(arr[Math.abs(k % 62)]));
		}

		return b.toString();
	}

}
