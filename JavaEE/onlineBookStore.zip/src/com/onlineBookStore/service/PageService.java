package com.onlineBookStore.service;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.onlineBookStore.util.HibernateSessionFactory;

public class PageService {
	@SuppressWarnings("unchecked")
	public List<?> list(int pageNow, int pageSize, String hql) {
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		List<Object> objects;
		Query query = session.createQuery(hql);
		query.setFirstResult(pageSize * (pageNow - 1));
		query.setMaxResults(pageSize);
		objects = query.list();
		tx.commit();
		return objects;
	}
}
