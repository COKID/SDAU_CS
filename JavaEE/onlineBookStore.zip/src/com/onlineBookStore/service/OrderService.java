package com.onlineBookStore.service;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.onlineBookStore.dao.OrderDAO;
import com.onlineBookStore.dao.UserinfoDAO;
import com.onlineBookStore.pojo.Order;
import com.onlineBookStore.pojo.Userinfo;
import com.onlineBookStore.util.HibernateSessionFactory;

public class OrderService {
	private OrderDAO orderdao = new OrderDAO();
	private UserinfoDAO userinfodao = new UserinfoDAO();

	@SuppressWarnings("unchecked")
	public List<Order> findOrderByUser(Userinfo userinfo) {
		Session session = HibernateSessionFactory.getSession();
		List<Order> orders = orderdao.findByProperty("userinfo", userinfo);
		Query query = session
				.createQuery("from Order as o where o.userinfo.id ='"
						+ userinfo.getId() + "'");
		query.setFirstResult(orders.size() - 3);
		query.setMaxResults(3);
		List list = query.list();
		return list;
	}
}
