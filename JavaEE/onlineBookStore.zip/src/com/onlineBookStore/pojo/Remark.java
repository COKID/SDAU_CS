package com.onlineBookStore.pojo;

import java.sql.Timestamp;

/**
 * Remark entity. @author MyEclipse Persistence Tools
 */

public class Remark implements java.io.Serializable {

	// Fields

	private Integer id;
	private Bookinfo bookinfo;
	private Userinfo userinfo;
	private String remark;
	private Timestamp date;

	// Constructors

	/** default constructor */
	public Remark() {
	}

	/** full constructor */
	public Remark(Bookinfo bookinfo, Userinfo userinfo, String remark,
			Timestamp date) {
		this.bookinfo = bookinfo;
		this.userinfo = userinfo;
		this.remark = remark;
		this.date = date;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Bookinfo getBookinfo() {
		return this.bookinfo;
	}

	public void setBookinfo(Bookinfo bookinfo) {
		this.bookinfo = bookinfo;
	}

	public Userinfo getUserinfo() {
		return this.userinfo;
	}
	
	public void setUserinfo(Userinfo userinfo) {
		this.userinfo = userinfo;
	}
    
	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Timestamp getDate() {
		return this.date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}

}