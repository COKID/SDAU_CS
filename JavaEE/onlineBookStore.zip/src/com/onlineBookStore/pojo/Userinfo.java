package com.onlineBookStore.pojo;

import java.util.HashSet;
import java.util.Set;

/**
 * Userinfo entity. @author MyEclipse Persistence Tools
 */

public class Userinfo implements java.io.Serializable {

	// Fields

	private Integer id;

	private String password;
	private String email;
	private Short power;
	private Set remarks = new HashSet(0);
	private Set addressinfos = new HashSet(0);
	private Set orders = new HashSet(0);

	// Constructors

	/** default constructor */
	public Userinfo() {
	}

	/** minimal constructor */
	public Userinfo(String password, String email) {

		this.password = password;
		this.email = email;
	}

	/** full constructor */
	public Userinfo(String password, String email, Short power, Set remarks,
			Set addressinfos, Set orders) {

		this.password = password;
		this.email = email;
		this.power = power;
		this.remarks = remarks;
		this.addressinfos = addressinfos;
		this.orders = orders;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Short getPower() {
		return this.power;
	}

	public void setPower(Short power) {
		this.power = power;
	}

	public Set getRemarks() {
		return this.remarks;
	}

	public void setRemarks(Set remarks) {
		this.remarks = remarks;
	}

	public Set getAddressinfos() {
		return this.addressinfos;
	}

	public void setAddressinfos(Set addressinfos) {
		this.addressinfos = addressinfos;
	}

	public Set getOrders() {
		return this.orders;
	}

	public void setOrders(Set orders) {
		this.orders = orders;
	}

}