package com.onlineBookStore.pojo;

/**
 * Addressinfo entity. @author MyEclipse Persistence Tools
 */

public class Addressinfo implements java.io.Serializable {

	// Fields

	private Integer id;
	private Userinfo userinfo;
	private String postcode;
	private String address;

	// Constructors

	/** default constructor */
	public Addressinfo() {
	}

	/** minimal constructor */
	public Addressinfo(Integer id, String postcode, String address) {
		this.id = id;
		this.postcode = postcode;
		this.address = address;
	}

	/** full constructor */
	public Addressinfo(Integer id, Userinfo userinfo, String postcode,
			String address) {
		this.id = id;
		this.userinfo = userinfo;
		this.postcode = postcode;
		this.address = address;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Userinfo getUserinfo() {
		return this.userinfo;
	}

	public void setUserinfo(Userinfo userinfo) {
		this.userinfo = userinfo;
	}

	public String getPostcode() {
		return this.postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}