package com.onlineBookStore.pojo;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * Bookinfo entity. @author MyEclipse Persistence Tools
 */

public class Bookinfo implements java.io.Serializable {

	// Fields

	private Integer id;
	private String bookName;
	private String isbn;
	private String writer;
	private String publisher;
	private String intro;
	private Double price;
	private Short remaining;
	private String picture;
	private Timestamp date;
	private String category;
	private Set orders = new HashSet(0);
	private Set remarks = new HashSet(0);

	// Constructors

	/** default constructor */
	public Bookinfo() {
	}

	/** minimal constructor */
	public Bookinfo(String bookName, String isbn, String writer,
			String publisher, Double price, Short remaining, Timestamp date,
			String catogory) {
		this.bookName = bookName;
		this.isbn = isbn;
		this.writer = writer;
		this.publisher = publisher;
		this.price = price;
		this.remaining = remaining;
		this.date = date;
		this.category = catogory;
	}

	/** full constructor */
	public Bookinfo(String bookName, String isbn, String writer,
			String catogory, String publisher, String intro, Double price,
			Short remaining, String picture, Timestamp date, Set orders,
			Set remarks) {
		this.bookName = bookName;
		this.isbn = isbn;
		this.writer = writer;
		this.publisher = publisher;
		this.intro = intro;
		this.price = price;
		this.remaining = remaining;
		this.picture = picture;
		this.date = date;
		this.orders = orders;
		this.remarks = remarks;
		this.category = catogory;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getBookName() {
		return this.bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getIsbn() {
		return this.isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getWriter() {
		return this.writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getPublisher() {
		return this.publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getIntro() {
		return this.intro;
	}

	public void setIntro(String intro) {
		this.intro = intro;
	}

	public Double getPrice() {
		return this.price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Short getRemaining() {
		return this.remaining;
	}

	public void setRemaining(Short remaining) {
		this.remaining = remaining;
	}

	public String getPicture() {
		return this.picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public Timestamp getDate() {
		return this.date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}

	public Set getOrders() {
		return this.orders;
	}

	public void setOrders(Set orders) {
		this.orders = orders;
	}

	public Set getRemarks() {
		return this.remarks;
	}

	public void setRemarks(Set remarks) {
		this.remarks = remarks;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

}