package com.onlineBookStore.util;

public class Pager {
	private int pageNow = 1;//
	private int pageSize = 7;//
	private int totalPage;//
	private int totalSize;//

	public Pager(int pageNow, int totalSize) {
		this.pageNow = pageNow;
		this.totalSize = totalSize;
	}

	public int getPageNow() {
		return pageNow;
	}

	public void setPageNow(int pageNow) {
		this.pageNow = pageNow;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getTotalPage() {

		totalPage = getTotalSize() / getPageSize();
		if (totalSize % pageSize != 0)
			totalPage++;
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getTotalSize() {
		return totalSize;
	}

	public void setTotalSize(int totalSize) {
		this.totalSize = totalSize;
	}

	public boolean isHasFirst() {

		if (pageNow == 1)
			return false;
		else
			return true;
	}

	public void setHasFirst(boolean hasFirst) {
	}

	public boolean isHasPre() {
		if (this.isHasFirst())
			return true;
		else
			return false;
	}

	public void setHasPre(boolean hasPre) {
	}

	public boolean isHasNext() {
		if (isHasLast())
			return true;
		else
			return false;
	}

	public void setHasNext(boolean hasNext) {
	}

	public boolean isHasLast() {
		if (pageNow == this.getTotalPage())
			return false;
		else
			return true;
	}

	public void setHasLast(boolean hasLast) {
	}
}
