package com.onlineBookStore.action;

import java.util.List;
import java.util.Map;

import com.onlineBookStore.service.PageService;
import com.onlineBookStore.service.RemarkService;
import com.onlineBookStore.util.Pager;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.onlineBookStore.pojo.Remark;
import com.onlineBookStore.pojo.Bookinfo;

public class RemarkAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7681842339481913564L;
	private int rowCount = 0;
	private int pageSize = 5;
	private int pageNo = 1;
	private int pageCount = 0;
	private String result;
	private int bookId;
	private PageService ps = new PageService();
	private RemarkService rs = new RemarkService();
    private List<Remark> remarks;
	public String getRemarkByBook() {
		
		Map<String, Object> session = (Map<String, Object>) ActionContext
				.getContext().get("session");
		int id=(int) session.get("bookId");
		String hql = "from Remark as r where r.bookinfo.id='" + id + "'";
		String s = rs.getAllCount(pageNo, pageSize, hql);
	    
		this.setResult(s);
		return this.SUCCESS;
	}
	public String getRemarkByBook_1() {
		Map<String, Object> session = (Map<String, Object>) ActionContext
				.getContext().get("session");
		int id=(int) session.get("bookId");
	
		String hql = "from Remark as r where r.bookinfo.id='" + id + "'";
		remarks = (List<Remark>) ps.list(1, 5, hql);
		if (remarks!= null) {
			Map<String, Object> request = (Map<String, Object>) ActionContext
					.getContext().get("request");
			//System.out.println(remarks.size());
			session.remove("remarks");
			session.put("remarks", remarks);
		}
		
				
		return this.SUCCESS;
	}
	
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public List<Remark> getRemarks() {
		return remarks;
	}
	public void setRemarks(List<Remark> remarks) {
		this.remarks = remarks;
	}
	public String rowCount() {
		
		Map<String, Object> session = (Map<String, Object>) ActionContext
				.getContext().get("session");
		int id=(int) session.get("bookId");
		String hql = "select count(*) from Remark as r where r.bookinfo.id='"
				+ id + "'";
		
		this.setRowCount(rs.count(hql));
		return "success";
	}

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getPageCount() {
		return pageCount;
	}

	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
