package com.onlineBookStore.action;

import java.util.List;
import java.util.Map;

import com.onlineBookStore.pojo.Order;
import com.onlineBookStore.pojo.Userinfo;
import com.onlineBookStore.service.OrderService;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class OrderAction extends ActionSupport {
	private Userinfo userinfo;
	private Order order;
	private List<Order> orders;
	private OrderService orderservice = new OrderService();

	public String index() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		Userinfo u = (Userinfo) session.get("userinfo");
		List<Order> orders = orderservice.findOrderByUser(u);
		this.setOrders(orders);
		return Action.SUCCESS;

	}

	public Userinfo getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(Userinfo userinfo) {
		this.userinfo = userinfo;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
}
