package com.onlineBookStore.action;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;

import com.onlineBookStore.pojo.BookCar;
import com.onlineBookStore.pojo.Bookinfo;
import com.onlineBookStore.pojo.Order;
import com.onlineBookStore.pojo.Userinfo;
import com.onlineBookStore.service.BookinfoService;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class BookCarAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3320254023162195908L;
	private int bookId;
	// private Map<String, String> cookie;
	private BookinfoService bs = new BookinfoService();
	private int remaining;
  
	public void addBookCar() throws Exception {
		ActionContext context = ActionContext.getContext();
		HttpServletResponse response = (HttpServletResponse) context
				.get(ServletActionContext.HTTP_RESPONSE);
		HttpServletRequest request = (HttpServletRequest) context
				.get(ServletActionContext.HTTP_REQUEST);
		String msg = null;
		Map<String, Object> session = context.getSession();
		
		Bookinfo book = bs.getBookById(bookId);
		List<BookCar> bookCars = (List<BookCar>) session.get("bookCars");
		if (book.getRemaining() > 0&&bs.deleteBookRemaining(book)) {
			BookCar bookCar=new BookCar();
			bookCar.setBookId(book.getId());
			bookCar.setBookName(book.getBookName());
			bookCar.setBookNumber(1);
			bookCar.setWriter(book.getWriter());
			bookCar.setPrice(book.getPrice());
			boolean temp = false;
			if (bookCars == null) {
				bookCars = new ArrayList<BookCar>();
				bookCars.add(bookCar);
			} else {
				for (int i = 0; i < bookCars.size(); i++) {
					if (bookCar.getBookId() == bookCars.get(i).getBookId()) {
						bookCars.get(i).setBookNumber(
								bookCars.get(i).getBookNumber() + 1);
						temp = true;
						break;
					}
				}
				if(temp==false){
					bookCars.add(bookCar);
				}

			}
			session.put("bookCars", bookCars);
			msg="已添加到购物车";
		}else {
			msg = "该图书暂时无货";
		}
		// int bookid=book.getId();
		// System.out.println(bookCar);
		response.setContentType("text/html; charset=utf-8");

		response.getWriter().write(msg);

		response.getWriter().flush();
		response.getWriter().close();

	}

	public void addBookCar_1() throws Exception {

		ActionContext context = ActionContext.getContext();
		HttpServletResponse response = (HttpServletResponse) context
				.get(ServletActionContext.HTTP_RESPONSE);
		HttpServletRequest request = (HttpServletRequest) context
				.get(ServletActionContext.HTTP_REQUEST);

		String msg = null;
		Map<String, Object> session = context.getSession();
		Bookinfo book = bs.getBookById(bookId);
		List<BookCar> bookCars = (List<BookCar>) session.get("bookCars");
		if (book.getRemaining() > 0 && bs.deleteBookRemaining(book, remaining)) {
			BookCar bookCar = new BookCar();
			bookCar.setBookId(book.getId());
			bookCar.setBookName(book.getBookName());
			bookCar.setBookNumber(remaining);
			bookCar.setWriter(book.getWriter());
			bookCar.setPrice(book.getPrice());
			boolean temp = false;
			if (bookCars == null) {
				bookCars = new ArrayList<BookCar>();
				bookCars.add(bookCar);
			} else {
				for (int i = 0; i < bookCars.size(); i++) {
					if (bookCar.getBookId() == bookCars.get(i).getBookId()) {
						bookCars.get(i).setBookNumber(
								bookCars.get(i).getBookNumber() + remaining);
						temp = true;
						break;
					}
				}
				if(temp==false){
					bookCars.add(bookCar);
				}

			}
			session.put("bookCars", bookCars);
			msg = "已添加到购物车";
		}
		// System.out.println(bookCar);
		response.setContentType("text/html; charset=utf-8");

		response.getWriter().write(msg);

		response.getWriter().flush();
		response.getWriter().close();

	}
    public String deleteBookCar(){
    	ActionContext context = ActionContext.getContext();
    	Map<String, Object> session = context.getSession();
    	List<BookCar> bookCars = (List<BookCar>) session.get("bookCars");
    	for(int i=0;i<bookCars.size();i++){
    		if(this.getBookId()==bookCars.get(i).getBookId()){
    			bs.addBookRemaining(bookCars.get(i).getBookId(), bookCars.get(i).getBookNumber());
    			bookCars.remove(i);
    		}
    	}
    	session.put("bookCars", bookCars);
    	return "success";
    	
    }
    public void deleteBookCar_1() throws Exception{
    	ActionContext context = ActionContext.getContext();
    	Map<String, Object> session = context.getSession();
    	HttpServletResponse response = (HttpServletResponse) context
				.get(ServletActionContext.HTTP_RESPONSE);
    	List<BookCar> bookCars = (List<BookCar>) session.get("bookCars");
    	for(int i=0;i<bookCars.size();i++){
    		if(this.getBookId()==bookCars.get(i).getBookId()){
    			bs.addBookRemaining(bookCars.get(i).getBookId(), bookCars.get(i).getBookNumber());
    			bookCars.remove(i);
    		}
    	}
    	session.put("bookCars", bookCars);
    	String msg="success";
    	response.setContentType("text/html; charset=utf-8");

		response.getWriter().write(msg);

		response.getWriter().flush();
		response.getWriter().close();

  
    	
    }
    
    public void settleOrder() throws Exception {
		ActionContext context = ActionContext.getContext();
		HttpServletResponse response = (HttpServletResponse) context
				.get(ServletActionContext.HTTP_RESPONSE);
		
		String msg = null;
		Map<String, Object> session = context.getSession();
		Userinfo userinfo=(Userinfo) session.get("userinfo");
		if(userinfo==null){
			msg="请先登录";
		}
		else{
			msg="1";
		}
		response.setContentType("text/html; charset=utf-8");

		response.getWriter().write(msg);

		response.getWriter().flush();
		response.getWriter().close();

	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public int getRemaining() {
		return remaining;
	}

	public void setRemaining(int remaining) {
		this.remaining = remaining;
	}

}
