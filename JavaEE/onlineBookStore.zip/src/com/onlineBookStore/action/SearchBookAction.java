package com.onlineBookStore.action;

import java.util.List;
import java.util.Map;
import com.onlineBookStore.pojo.Bookinfo;
import com.onlineBookStore.service.BookinfoService;
import com.onlineBookStore.service.PageService;
import com.onlineBookStore.util.Pager;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class SearchBookAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3571164226197852133L;

	private Bookinfo bookinfo;

	private int bookId;
	private PageService ps = new PageService();
	private List<Bookinfo> bookinfos;
	private int pageNow = 1;
	private int pageSize = 10;
	private String category;
	private String searchOfWord;
	private BookinfoService bsf = new BookinfoService();
	static final String novel = "小说";
	static final String art = "文艺";
	static final String youth = "青春";
	static final String motivational = "励志";
	static final String tale = "童话";
	static final String life = "生活";
	static final String science = "社科";
	static final String management = "经管";
	static final String technology = "科技";
	static final String education = "教育";

	public String searchBook() {
		String temp = null;
		if (category.equals("novel")) {
			temp = novel;
		} else if (category.equals("art")) {
			temp = art;
		} else if (category.equals("youth")) {
			temp = youth;
		} else if (category.equals("motivational")) {
			temp = motivational;
		} else if (category.equals("tale")) {
			temp = tale;
		} else if (category.equals("life")) {
			temp = life;
		} else if (category.equals("science")) {
			temp = science;
		} else if (category.equals("management")) {
			temp = management;
		} else if (category.equals("technology")) {
			temp = technology;
		} else if (category.equals("education")) {
			temp = education;
		}
		// System.out.println(temp+"xxx");
		// String t=temp.toString();
		String hql = "from Bookinfo b where b.category='" + temp
				+ "' order by b.date desc";
		bookinfos = (List<Bookinfo>) ps.list(pageNow, pageSize, hql);
		if (bookinfos != null) {
			Map<String, Object> request = (Map<String, Object>) ActionContext
					.getContext().get("request");
			Pager page = new Pager(this.getPageNow(),
					bsf.getBookSizeByCategory(category));

			request.put("bookinfos", bookinfos);

			request.put("page", page);
			request.put("category", this.getCategory());
			return Action.SUCCESS;
		} else {
			return Action.ERROR;
		}

	}

	public String searchBookByWord() throws Exception {
		ActionContext context = ActionContext.getContext();

		Map<String, Object> request = (Map<String, Object>) ActionContext
				.getContext().get("request");

		bookinfos = (List<Bookinfo>) bsf.list(pageNow, pageSize,
				this.getSearchOfWord());
		if (bookinfos != null) {

			Pager page = new Pager(this.getPageNow(),
					bsf.getBookSizeByWord(this.getSearchOfWord()));

			request.put("bookinfos", bookinfos);

			request.put("page", page);
			request.put("searchOfWord", searchOfWord);
			return Action.SUCCESS;
		} else {
			return Action.ERROR;
		}

	}

	// public String
	public List<Bookinfo> getBookinfos() {
		return bookinfos;
	}

	public void setBookinfos(List<Bookinfo> bookinfos) {
		this.bookinfos = bookinfos;
	}

	public int getPageNow() {
		return pageNow;
	}

	public void setPageNow(int pageNow) {
		this.pageNow = pageNow;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public Bookinfo getBookinfo() {
		return bookinfo;
	}

	public void setBookinfo(Bookinfo bookinfo) {
		this.bookinfo = bookinfo;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSearchOfWord() {

		return searchOfWord;
	}

	public void setSearchOfWord(String searchOfWord) {
		this.searchOfWord = searchOfWord;
	}

}
