package com.onlineBookStore.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;

import com.onlineBookStore.pojo.Bookinfo;
import com.onlineBookStore.service.BookinfoService;
import com.onlineBookStore.service.PageService;
import com.onlineBookStore.util.Pager;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class BookinfoAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3426437685428545025L;
	private Bookinfo bookinfo;
	private PageService ps = new PageService();
	private BookinfoService bsf = new BookinfoService();
	private int bookId;
	private List<Bookinfo> bookinfos;
	private int pageNow = 1;
	private int pageSize = 7;
	private File file;
	private String fileFileName;
	private String fileFileContentType;
	private String savePath;
	private String message;

	public String getLastBook() {
		ActionContext ac = ActionContext.getContext();
		Map session = ac.getSession();
		List<Bookinfo> bis = null;
		List<Bookinfo> bis1 = new ArrayList<Bookinfo>();
		bis = bsf.getLastBook();
		if (bis != null) {
			for (int i = bis.size() - 1; i >= bis.size() - 19; i--) {
				bis1.add(bis.get(i));

			}
			session.put("bookinfos", bis1);
			return "success";
		}
		return "error";
	}

	public String listBook() {
		String hql = "from Bookinfo b";
		if (ps.list(pageNow, pageSize, hql) != null) {
			bookinfos = (List<Bookinfo>) ps.list(pageNow, pageSize, hql);

			Map<String, Object> request = (Map<String, Object>) ActionContext
					.getContext().get("request");
			Pager page = new Pager(this.getPageNow(), bsf.getBookSize());

			request.put("bookinfos", bookinfos);

			request.put("page", page);

			return Action.SUCCESS;
		} else {
			return Action.LOGIN;
		}
	}

	public String getBookById() {
		this.setBookinfo(bsf.getBookById(bookId));
		Map<String, Object> request = (Map<String, Object>) ActionContext
				.getContext().get("request");
		Map<String, Object> session = (Map<String, Object>) ActionContext
				.getContext().get("session");
		if (this.getBookinfo() != null) {
			request.put("pageNow", pageNow);
			session.put("bookId", bookId);
			return "success";
		} else {
			return "error";
		}
	}

	public String deleteBook() {
		if (bsf.deleteBook(bookId) == true) {
			return "success";
		} else {
			return "error";
		}
	}

	public void uploadBookPicture() throws Exception {
		ActionContext context = ActionContext.getContext();

		Map session = context.getSession();
		HttpServletResponse response = (HttpServletResponse) context
				.get(ServletActionContext.HTTP_RESPONSE);
		try {
			if (this.getFileFileName().endsWith(".exe")) {
				setMessage("对不起,你上传的文件格式不允许!!!");
				// return ERROR;
			}
			InputStream is = new FileInputStream(this.getFile());
			String uploadPath = ServletActionContext.getServletContext()
					.getRealPath("/upload");

			OutputStream os = new FileOutputStream(new File(uploadPath,
					this.getFileFileName()));
			byte[] buffer = new byte[1024];
			int length = 0;
			while ((length = is.read(buffer)) != -1) {
				os.write(buffer, 0, length);
			}
			this.closeFile(os, is);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		String data = "upload/" + fileFileName;
		session.put("fileName", this.getFileFileName());
		response.setContentType("text/html; charset=utf-8");
		//
		response.getWriter().write(data);
		response.getWriter().flush();
		response.getWriter().close();
		// return Action.SUCCESS;
	}

	private void closeFile(OutputStream os, InputStream is) {
		if (is != null) {
			try {
				is.close();
			} catch (IOException e) {
				System.out.println("InputStream关闭失败");
				e.printStackTrace();
			}
		}
		if (os != null) {
			try {
				os.close();
			} catch (IOException e) {
				System.out.println("OutputStream关闭失败");
				e.printStackTrace();
			}
		}
	}

	public String addBookinfo() {
		ActionContext context = ActionContext.getContext();
		Map session = context.getSession();
		bookinfo.setPicture((String) session.get("fileName"));
		if (bsf.addBookinfo(bookinfo) == true) {
			return "success";
		}

		return "error";
	}

	public Bookinfo getBookinfo() {
		return bookinfo;
	}

	public void setBookinfo(Bookinfo bookinfo) {
		this.bookinfo = bookinfo;
	}

	public List<Bookinfo> getBookinfos() {
		return bookinfos;
	}

	public void setBookinfos(List<Bookinfo> bookinfos) {
		this.bookinfos = bookinfos;
	}

	public int getPageNow() {
		return pageNow;
	}

	public void setPageNow(int pageNow) {
		this.pageNow = pageNow;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getSavePath() {
		return savePath;
	}

	public void setSavePath(String savePath) {
		this.savePath = savePath;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public String getFileFileName() {
		return fileFileName;
	}

	public void setFileFileName(String fileFileName) {
		this.fileFileName = fileFileName;
	}

	public String getFileFileContentType() {
		return fileFileContentType;
	}

	public void setFileFileContentType(String fileFileContentType) {
		this.fileFileContentType = fileFileContentType;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
