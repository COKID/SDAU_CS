package com.onlineBookStore.action;

import java.util.List;
import java.util.Map;

import com.onlineBookStore.pojo.Userinfo;
import com.onlineBookStore.service.PageService;
import com.onlineBookStore.service.UserinfoService;
import com.onlineBookStore.util.Pager;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class UserinfoAction extends ActionSupport {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6874828383146940762L;
	private Userinfo userinfo;
	private UserinfoService us = new UserinfoService();
	private int pageNow = 1;
	private int pageSize = 7;
	private List<Userinfo> userinfos;
	private PageService ps = new PageService();
	private int userid;
	private String power;

	public String login() {
		ActionContext actionContext = ActionContext.getContext();
		Map<String, Object> session = actionContext.getSession();
		Userinfo u = null;
		if (userinfo != null) {
			if (us.login(userinfo.getEmail(), userinfo.getPassword()) != null) {
				u = us.login(userinfo.getEmail(), userinfo.getPassword());
				session.put("userinfo", u);
				return "success";
			} else {
				return "error";
			}
		} else {
			return "input";
		}
	}

	public String register() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		Userinfo u = null;
		if (userinfo != null) {
			userinfo.setPower((short) 1);
			u = us.addUser(userinfo);
			if (u != null) {
				session.put("userinfo", u);
				return Action.SUCCESS;
			} else {
				return Action.ERROR;

			}
		} else {
			return Action.INPUT;
		}
	}

	public String addUser() {
		userinfo.setPower((short) 1);
		if (us.addUser(userinfo) != null) {
			return "success";
		} else {
			return "error";
		}
	}

	public String logout() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		session.clear();
		return Action.SUCCESS;
	}

	public String modifyUserByUser() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		Userinfo user = (Userinfo) session.get("userinfo");
		Userinfo u = us.modifyUser(user, userinfo);

		session.put("userinfo", u);
		return "success";
	}

	public String getUserById() {
		this.setUserinfo(us.getUserById(userid));
		this.setPageNow(pageNow);
		return "success";
	}

	public String modifyUserByAdmin() {
		this.setPageNow(pageNow);
		if (us.modifyUserByAdmin(userinfo) == true) {
			return "success";
		} else
			return "error";
	}

	public String listUser() {
		String hql = "from Userinfo u";
		if (ps.list(pageNow, pageSize, hql) != null) {
			userinfos = (List<Userinfo>) ps.list(pageNow, pageSize, hql);
			Map<String, Object> request = (Map<String, Object>) ActionContext
					.getContext().get("request");
			Pager page = new Pager(this.getPageNow(), us.getUserSize());
			request.put("userinfos", userinfos);
			request.put("page", page);

			return Action.SUCCESS;
		} else {
			return Action.LOGIN;
		}
	}

	public String deleteUser() {

		if (us.deleteUser(userid) == true) {
			return "success";
		} else {
			return "error";
		}
	}

	public int getPageNow() {
		return pageNow;
	}

	public void setPageNow(int pageNow) {
		this.pageNow = pageNow;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getPower() {
		return power;
	}

	public void setPower(String power) {
		this.power = power;
	}

	public Userinfo getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(Userinfo userinfo) {
		this.userinfo = userinfo;
	}

}
