package com.online.entity;

/**
 * Created by LIULEI on 2017/1/3.
 */
public class Order {
}
